
/**
*@author Venegas Guerrero Fatima Alejandra
*@version 1.0
*/

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.*;
import java.util.Random;

public class Azar extends JFrame{
	
	BufferedImage image= null;
	int width;
	int height;

	public Azar(){
		super("Colores al Azar");
		Cazar();
		setSize(900,900);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);

	}//fin del constructor Azar

	public void Cazar(){
		try{
			File input = new File("an.jpg");
			image=ImageIO.read(input);
			width=image.getWidth();
			height=image.getHeight();

			Random rnd = new Random();
			for(int i=0;i<height;i++){
				for(int j=0;j<width; j++){
					Color c = new Color(image.getRGB(j,i));
					int green = (rnd.nextInt(255)+1);
					int red=(rnd.nextInt(255)+1);
					int blue=(rnd.nextInt(255)+1);
					Color newColor = new Color(red,green,blue);
					image.setRGB(j,i,newColor.getRGB());

				}
			}
			File up = new File("Azar.jpg");
			ImageIO.write(image,"jpg",up);
		}catch(Exception e){}

	}//fin del metodo Cazar

	public void paint(Graphics g){
		 	ImageIcon imen = new ImageIcon(getClass().getResource("Azar.jpg"));
		g.drawImage(image,10,10,getWidth()-10,getHeight()-10,null);


	}

	public void ventanaR(){
		    int res = JOptionPane.showConfirmDialog(null,"Quieres probar otro Filtro?","Filtro",
         JOptionPane.INFORMATION_MESSAGE);
            if(res==JOptionPane.YES_OPTION){
               Filtros fe = new Filtros();
               fe.menu();
               
            }else{
               JOptionPane.showMessageDialog(null,"HASTA LUEGO!!! ");
               System.exit(0);

            }
	}
	
	static public void main(String args[])throws Exception{
		Azar obj = new Azar();
	}

}//fin de la clase Azar
