/**
 * @author Venegas Guerreo Fatima Alejandra
 * num cuenta: 310318738
 */

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.*;
import java.util.Random;
import java.util.Arrays;
import java.awt.image.ConvolveOp;
import java.awt.image.BufferedImageOp;
import java.awt.image.Kernel;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;
import javax.swing.text.BadLocationException;
import java.awt.AlphaComposite;
import java.util.Random;


public class Filtros7{

       //Método auxiliar de dithering
       public int diferencia(Color c1, Color c2){
        int difRed = c1.getRed() - c2.getRed();
        int difGreen = c1.getGreen() - c2.getGreen();
        int difBlue = c1.getBlue() - c2.getBlue();
        int difTotal = difRed*difRed + difGreen*difGreen + difBlue*difBlue;
        return difTotal;
    }


    //Método auxiliar de dithering
    public Color colorMasCercano(Color c){
        Color c1 = new Color(0,0,0);
        Color c2 = new Color(0,0,255);
        Color c3 = new Color(0,255,0);
        Color c4 = new Color(0, 255, 255);
        Color c5 = new Color(255, 0, 0);
        Color c6 = new Color(255, 0, 255);
        Color c7 = new Color(255, 255, 0);
        Color c8 = new Color(255, 255, 255);
        
        //Paleta de colores disponibles
        Color[] paleta = {c1, c2, c3, c4, c5, c6, c7, c8};
        Color col = paleta[0];
        for(int i = 0; i < paleta.length; i++){
            if(diferencia(c, paleta[i]) < diferencia(c, col)){
                col = paleta[i];
            }
        }
        return col;
    }



    /*
    *Método que aplica el filtro de dithering con difusión de error
    */
    public BufferedImage dithering(BufferedImage imagen){
               
        for(int y = 0; y < imagen.getHeight(); y++){
            for(int x = 0; x < imagen.getWidth(); x++){
                Color aux = new Color(imagen.getRGB(x, y));
                int red = aux.getRed();
                int green = aux.getGreen();
                int blue = aux.getBlue();
               //Se obtiene el color más cercano de la paleta de colores con respecto a la posición (x,y) de la imagen
                Color nuevo = colorMasCercano(aux);
                int nuevoRed = nuevo.getRed();
                int nuevoGreen = nuevo.getGreen();
                int nuevoBlue = nuevo.getBlue();
                //Se modifica el nuevo color
                imagen.setRGB(x, y, nuevo.getRGB());
                int error_Red = red - nuevoRed;
                int error_Green = green -nuevoGreen;
                int error_Blue = blue -nuevoBlue;
                
                //Se modifica el nuevo color en la posición (x+1, y)
                if(x < (imagen.getWidth() - 1)){
                    Color nuevo2 = new Color(imagen.getRGB(x+1, y));
                    int red1 = (int)(nuevo2.getRed() + error_Red * (7.0 / 16));
                    if(red1 < 0 || red1 > 255) red1 = 255;//System.out.println(1 + " red: " + red1);
                    int green1 = (int)(nuevo2.getGreen() + error_Green * (7.0 / 16));
                    if(green1 < 0 || green1 > 255) green1 = 255;//System.out.println(1 + " green: " + green1);
                    int blue1 = (int)(nuevo2.getBlue() + error_Blue * (7.0 / 16));
                    if(blue1 < 0 || blue1 > 255) blue1 = 255; //System.out.println(1 + " blue: " + blue1);
                    //System.out.println(red1 + " " + green1 + " " + blue1);
                    Color nuevo3 = new Color(red1, green1, blue1);
                    imagen.setRGB(x+1, y, nuevo3.getRGB());
                }
                
                //Se modifica el nuevo color en la posición (x-1, y+1)
                if((y < (imagen.getHeight() - 1)) && (x > 0)){
                    Color nuevo4 = new Color(imagen.getRGB(x-1, y+1));
                    int red2 = (int)(nuevo4.getRed() + error_Red * (3.0 / 16));
                    if(red2 < 0 || red2 > 255) red2 = 255;//System.out.println(2 + " red: " + red2);
                    int green2 = (int)(nuevo4.getGreen() + error_Green * (3.0 / 16));
                    if(green2 < 0 || green2 > 255) green2 = 255;//System.out.println(2 + " green: " + green2);
                    int blue2 = (int)(nuevo4.getBlue() + error_Blue * (3.0 / 16));
                    if(blue2 < 0 || blue2 > 255) blue2 = 255;//System.out.println(2 + " blue: " + blue2);
                    //System.out.println(red2 + " " + green2 + " " + blue2);
                    Color nuevo5 = new Color(red2, green2, blue2);
                    imagen.setRGB(x-1, y+1, nuevo5.getRGB());
                }
                
                //Se modifica el nuevo color en la posición (x, y+1)
                if(y < (imagen.getHeight() -1)){
                    Color nuevo6 = new Color(imagen.getRGB(x, y+1));
                    int red3 = (int)(nuevo6.getRed() + error_Red * (5.0 / 16));
                    if(red3 < 0 || red3 > 255) red3 = 255;//System.out.println(3 + " red: " + red3);
                    int green3 = (int)(nuevo6.getGreen() + error_Green * (5.0 / 16));
                    if(green3 < 0 || green3 > 255) green3 = 255;//System.out.println(3 + " green: " + green3);
                    int blue3 = (int)(nuevo6.getBlue() + error_Blue * (5.0 / 16));
                    if(blue3 < 0 || blue3 > 255) blue3 = 255;//System.out.println(3 + " blue: " + blue3);
                    //System.out.println(red3 + " " + green3 + " " + blue3);
                    Color nuevo7 = new Color(red3, green3, blue3);
                    imagen.setRGB(x, y+1, nuevo7.getRGB());
                    
                }
                
                //Se modifica el nuevo color en la posición (x+1, y+1)
                if((y < (imagen.getHeight() - 1)) && (x < (imagen.getWidth() - 1))){
                    Color nuevo8 = new Color(imagen.getRGB(x+1, y+1));
                    int red4 = (int)(nuevo8.getRed() + error_Red * (1.0 / 16));
                    if(red4 < 0 || red4 > 255) red4 = 255;//System.out.println(4 + " red: " + red4);
                    int green4 = (int)(nuevo8.getGreen() + error_Green * (1.0 / 16));
                    if(green4 < 0 || green4 > 255) green4 = 255;//System.out.println(4 + " green: " + green4);
                    int blue4 = (int)(nuevo8.getBlue() + error_Blue * (1.0 / 16));
                    if(blue4 < 0 || blue4 > 255) blue4 = 255;//System.out.println(4 + " blue: " + blue4);
                    //System.out.println(red4 + " " + green4 + " " + blue4);
                    Color nuevo9 = new Color(red4, green4, blue4);
                    imagen.setRGB(x+1, y+1, nuevo9.getRGB());
                }
                               
            }
            
        }
      return imagen;
    }
    

/*
*
*Algoritmo de dithering ordenado
*/

public BufferedImage ditheringR(BufferedImage imagen){

    //Bayer Matriz
    int[][] matrix = {   
        {
          8,3,4
        }
        , 
        {
         6,1,2
        }
        , 
        {
          7,5,9
        }
        
      };


      for(int y=0; y<imagen.getHeight();y++){
        for(int x=0; x<imagen.getWidth();x++){
           

            Color aux = new Color(imagen.getRGB(x,y));
          
            int red = aux.getRed();
            int green = aux.getGreen();
            int blue = aux.getBlue();
           //Se obtiene el color más cercano de la paleta de colores con respecto a la posición (x,y) de la imagen
            Color nuevo = colorMasCercano(aux);
            int nuevoRed = nuevo.getRed() / 28;
            int nuevoGreen = nuevo.getGreen() / 28;
            int nuevoBlue = nuevo.getBlue()/28;
           
            if(nuevoRed<matrix[x%3][y%3] || nuevoGreen<matrix[x%3][y%3] || nuevoBlue<matrix[x%3][y%3]){
                red=255;
                green=255;
                blue=255;
            }else{
                red=0;
                green=0;
                blue=0;
            }
      
            Color nuevo9 = new Color(red, green, blue);
            imagen.setRGB(x, y, nuevo9.getRGB());
              
        }
    }
            return imagen;


    }

/*
* Algoritmo de dithering a la azar utilizando bayer
*/
    public BufferedImage ditheringAz(BufferedImage imagen){

        int s =1;
        Random rnd= new Random();
        for(int j=0; j<imagen.getHeight();j+=s){
            for(int k=0; k<imagen.getWidth();k+=s){
               

                Color aux = new Color(imagen.getRGB(k,j));
                
                int red = aux.getRed() + ((int)(rnd.nextInt(64-(-84)+1)+64));
                int green = aux.getGreen() + ((int)(rnd.nextInt(64-(-64)+1)+64));
                int blue = aux.getBlue() + ((int)(rnd.nextInt(64-(-64)+1)+64));
               //Se obtiene el color más cercano de la paleta de colores con respecto a la posición (x,y) de la imagen
                Color nuevo = colorMasCercano(aux);
                int nuevoRed = nuevo.getRed();
                int nuevoGreen = nuevo.getGreen();
                int nuevoBlue = nuevo.getBlue();
               
                imagen.setRGB(k,j,nuevo.getRGB());

            }

        }
    
        return imagen;


    }//fin de la clase dithering radom

    /*
    *Algoritmo de dithering disperso 
    *
    */
    public BufferedImage ditheringDis(BufferedImage imagen){

        

        int[][] matrix = {   
            {
              1, 7, 4
            }
            , 
            {
              5, 8, 3
            }
            , 
            {
              6, 2, 9
            }
         
          };
        
        for(int y=0; y<imagen.getHeight();y++){
            for(int x=0; x<imagen.getWidth();x++){
               

                Color aux = new Color(imagen.getRGB(x,y));
              
                int red = aux.getRed();
                int green = aux.getGreen();
                int blue = aux.getBlue();
               //Se obtiene el color más cercano de la paleta de colores con respecto a la posición (x,y) de la imagen
                Color nuevo = colorMasCercano(aux);
                int nuevoRed = nuevo.getRed() / 28;
                int nuevoGreen = nuevo.getGreen() / 28;
                int nuevoBlue = nuevo.getBlue()/28;
               
                if(nuevoRed<matrix[x%3][y%3] || nuevoGreen<matrix[x%3][y%3] || nuevoBlue<matrix[x%3][y%3]){
                    red=255;
                    green=255;
                    blue=255;
                }else{
                    red=0;
                    green=0;
                    blue=0;
                }
          
                Color nuevo9 = new Color(red, green, blue);
                imagen.setRGB(x, y, nuevo9.getRGB());
                  
            }
        }
    
        return imagen;


    }//fin del algoritmo disperso




}//fin de la clase